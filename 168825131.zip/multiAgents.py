# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        #newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        Gs = [manhattanDistance(ghost.configuration.pos, newPos) for ghost in newGhostStates]
        nearestG = min(Gs)
        dangous = -1000 if nearestG<2 else 0
        if len(newFood.asList())>0:
            Foods = [manhattanDistance(food, newPos) for food in newFood.asList()]
            nearestF = min(Foods)
            foodH = 9/nearestF
        else:
            foodH = 0

        return successorGameState.getScore() + dangous + foodH

def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        valMax = -float('inf')
        best= None
        for x in gameState.getLegalActions(0):
            val = self.gMin(gameState.generateSuccessor(0, x),0,1)
            if val>valMax:
                valMax = val
                best = x
        return best  

    def gMax(self,gameState,depth=0,agentIndex=0):
        if depth == self.depth:
            return self.evaluationFunction(gameState)
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState)
        valMax = -float('inf')
        for action in gameState.getLegalActions(agentIndex):
            value = self.gMin(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1)
            if value>valMax:
                valMax = value
        return valMax            

    def gMin(self,gameState,depth=0,agentIndex=1):
        if depth == self.depth:
            return self.evaluationFunction(gameState)
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState)
        minVal = float('inf')
        for action in gameState.getLegalActions(agentIndex):
            if agentIndex == gameState.getNumAgents()-1:
                value = self.gMax(gameState.generateSuccessor(agentIndex, action),depth+1,0)
            else:
                value = self.gMin(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1)
            if value<minVal:
                minVal = value
        return minVal

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        maxVal, bestAction = self.gMax(gameState)
        return bestAction
       
    


    def gMax(self,gameState,depth=0,agentIndex=0,alpha=-float('inf'),beta=float('inf')):
        if depth == self.depth:
            return self.evaluationFunction(gameState),None
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState),None
        valMax = -float('inf')
        bestAction = None
        for action in gameState.getLegalActions(agentIndex):
            val = self.gMin(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1,alpha,beta)[0]
            if val>valMax:
                valMax = val
                bestAction = action
            if val>beta:
                return val,action
            alpha = val if val>alpha else alpha
        return valMax,bestAction

    def gMin(self,gameState,depth=0,agentIndex=1,alpha=-float('inf'),beta=float('inf')):
        if depth == self.depth:
            return self.evaluationFunction(gameState),None
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState),None
        valMin = float('inf')
        bestAction = None
        for action in gameState.getLegalActions(agentIndex):
            if agentIndex == gameState.getNumAgents()-1:
                val = self.gMax(gameState.generateSuccessor(agentIndex, action),depth+1,0,alpha,beta)[0]
            else:
                val = self.gMin(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1,alpha,beta)[0]
            if val<valMin:
                valMin = val
                bestAction = action
            if val<alpha:
                return val,action
            beta = val if val<beta else beta 
        return valMin,bestAction

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        return self.gMax(gameState)[1]


    def gMax(self,gameState,depth=0,agentIndex=0):
        if depth == self.depth:
            return self.evaluationFunction(gameState),None
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState),None
        valMax = -float('inf')
        bestA = None
        for action in gameState.getLegalActions(agentIndex):
            val = self.gExpect(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1)
            if val>valMax:
                valMax = val
                bestA = action
        return valMax,bestA

    def gExpect(self,gameState,depth,agentIndex=1):
        if depth == self.depth:
            return self.evaluationFunction(gameState)
        if len(gameState.getLegalActions(agentIndex)) == 0:
            return self.evaluationFunction(gameState)
        totalU = 0
        for action in gameState.getLegalActions(agentIndex):
            if agentIndex == gameState.getNumAgents()-1:
                val = self.gMax(gameState.generateSuccessor(agentIndex, action),depth+1,0)[0]
                totalU += val
            else:
                val = self.gExpect(gameState.generateSuccessor(agentIndex, action),depth,agentIndex+1)
                totalU += val
        return totalU/len(gameState.getLegalActions(agentIndex))

def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    pacmanP = currentGameState.getPacmanPosition()
    gStates = currentGameState.getGhostStates()
    foods = currentGameState.getFood().asList()
    scaredT = [ghost.scaredTimer for ghost in gStates]
    
    if len(foods)>0:
        Foods = [manhattanDistance(food, pacmanP) for food in foods]
        nearest = min(Foods)
        foodH = 0
    else:
        foodH = 0
        
    if len(gStates)>0:
        Ghosts = [manhattanDistance(ghost.configuration.pos, pacmanP) for ghost in gStates]
        nearestGhost = min(Ghosts)
        dangousScore = -1000 if nearestGhost<2 else 0

    totalScaredT = sum(scaredT)
    
    return  currentGameState.getScore() + foodH+ dangousScore + totalScaredT

# Abbreviation
better = betterEvaluationFunction
