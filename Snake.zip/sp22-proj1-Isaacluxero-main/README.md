# 61C Spring 2022 Project 1: Snake

Spec: [https://cs61c.org/sp22/projects/proj1/](https://cs61c.org/sp22/projects/proj1/)

The project was really interesting! Since C is new, each task took a few hours to complete. However, it was nice to start with a non-computer architecture in order to get the hang of C. The most fun and useful part for me was learning how to allocate memory correctly. The most frustrating thing was task 7, because we ran into bugs when running all of the functions together. The least fun part was task 1 and task 5. It was also quite challenging to understand how to allocate the char**'s to store the board characters, and loading from the file was also challenging to understand how to implement without having gone over these libraries at all in class. 
